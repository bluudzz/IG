# Instagram Bot Tools

How to install on Termux
* pkg install nodejs
* pkg install git
* git clone https://github.com/auliaahmad165/IG.git
* cd IG
* npm install

Thank's To https://github.com/huttarichard/instagram-private-api For API

# Follow https://www.instagram.com/auliaahmad16/
